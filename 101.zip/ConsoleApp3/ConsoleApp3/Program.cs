﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace N14310010_115_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student();
            student.id = "B04170082";
            student.name = "Amy";
            Console.WriteLine("ID:" + student.id + " Name:" + student.name);

            Student student2 = new Student();
            student2.id = "B1234578";
            student2.name = "林昱辰";
            Console.WriteLine("ID:" + student2.id + " Name:" + student2.name);

            Student student3 = new Student("B1234574", "林老木");
            Console.WriteLine("ID:" + student3.id + " Name:" + student3.name);

            Console.ReadLine();
        }
    }

    public class Student
    {
        public string id;
        public string name;

        public Student() { }
        public Student(String id,String name)
        {
            this.id=id;//this=這個物件 ,=的
            this.name=name;
        }
    }
}